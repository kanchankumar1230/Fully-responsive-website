function shownav(){
    var show = document.querySelector('.hide')
    show.style.display='block' /* ya flex v use kr sakte hai */
}
function hidenav(){
    var hide=document.querySelector('.hide')
    hide.style.display='none'
}
